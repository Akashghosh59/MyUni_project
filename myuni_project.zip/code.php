<?php
session_start();

$connection = mysqli_connect("127.0.0.1","root","","portal_db");

if (isset($_POST['registerbtn']))
{
  $username = $_POST['username'];
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $mob = $_POST['mob'];
  $gender = $_POST['gender'];
  $email = $_POST['email'];
  $add = $_POST['add'];
  $Postcode = $_POST['Postcode'];
  $pwd =md5($_POST['pwd']);
  $cpassword = md5($_POST['confirm_password']);


  if($pwd === $cpassword)
  {

 

    $query = "INSERT INTO user_data (username,fname,lname,mob,gender,email,add,Postcode,pwd) VALUES ('$username','$fname','$lname','$mob','$gender','$email','$add','$Postcode','$pwd')";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
          {
            echo "done";
            $_SESSION['success'] =  "User is Added Successfully";
            header('Location: register.php');
          }
    else 
          {
            echo "not done";
            $_SESSION['status'] =  "User is Not Added";
            header('Location: register.php');
          }
  }        
  else 
    {
      echo "Password Does not Match";
      $_SESSION['status'] =  "Admin is Not Added";
      header('Location: register.php');
    }
  
}




if(isset($_POST['updatebtn']))
{
  $id = $_POST['edit_id'];
  $username = $_POST['edit_username'];
  $fname = $_POST['edit_fname'];
  $lname = $_POST['edit_lname'];
  $mob = $_POST['edit_mob'];
  $gender = $_POST['edit_gender'];
  $email = $_POST['edit_	email'];
  $add = $_POST['edit_add'];
  $Postcode = $_POST['edit_Postcode'];
  $pwd = md5($_POST['edit_pwd']);


  $query ="UPDATE user_data SET username='$username',fname='$fname',lname='$lname',mob ='$mob',gender='$gender' ,email='$email',add='$add',Postcode='$Postcode',pwd='$pwd'  WHERE id='$id'";
  $query_run = mysqli_query($connection, $query);

  if($query_run)
          {
            
            $_SESSION['success'] =  "User Data Updated";
            header('Location: register.php');
          }
    else 
          {
            
            $_SESSION['status'] =  "User Data is Not Updated";
            header('Location: register.php');
          }
}

if(isset($_POST['delete_btn']))
  {
    $id = $_POST['delete_id'];
    $query="DELETE FROM user_data WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);


    if($query_run)
          {
            
            $_SESSION['success'] =  "User Data is Deleted";
            header('Location: register.php');
          }
    else 
          {
            
            $_SESSION['status'] =  "went wrong";
            header('Location: register.php');
          }
}


// include('security.php');
if(isset($_POST['login_btn']))
{
  
  $username_login = $_POST['username'];
  $pwd_login =md5($_POST['pwd']);
  $query="SELECT * FROM admin_panel WHERE username='$username_login' AND pwd='$pwd_login' ";
  $query_run = mysqli_query($connection, $query);

  if(mysqli_fetch_array($query_run))
  {
            
    $_SESSION['username'] =  $username_login;
    header('Location: index.php');
  }
  else 
  {
            
    $_SESSION['status'] =  "Username/password is invalid";
    header('Location: login.php');
  }
}

 


?>